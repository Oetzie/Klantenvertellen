<?php

    /**
     * Klantenvertellen
     *
     * Copyright 2018 by Oene Tjeerd de Bruin <modx@oetzie.nl>
     */
    
    $xpdo_meta_map = [
        'xPDOSimpleObject' => [
            'KvReview'
        ]
    ];
	
?>