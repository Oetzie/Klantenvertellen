<?php

    /**
     * Klantenvertellen
     *
     * Copyright 2018 by Oene Tjeerd de Bruin <modx@oetzie.nl>
     */
    
    require_once dirname(__DIR__) . '/kvreview.class.php';
    
    class KvReview_mysql extends KvReview {}
	
?>