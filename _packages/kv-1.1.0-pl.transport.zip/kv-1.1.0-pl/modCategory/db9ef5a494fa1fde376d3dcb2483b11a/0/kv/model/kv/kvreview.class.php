<?php
	
    /**
     * Klantenvertellen
     *
     * Copyright 2018 by Oene Tjeerd de Bruin <modx@oetzie.nl>
     */
    
    class KvReview extends xPDOSimpleObject {}
	
?>