----------------------
Klantenvertellen
----------------------
Version: 1.1.0
Author: Oene Tjeerd de Bruin
Contact: modx@oetzie.nl
----------------------

To use this component the user needs to have the "kv" permissions.