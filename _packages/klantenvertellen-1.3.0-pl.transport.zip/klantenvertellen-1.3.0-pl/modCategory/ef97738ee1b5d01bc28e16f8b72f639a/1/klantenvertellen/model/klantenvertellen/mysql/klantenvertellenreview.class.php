<?php

/**
 * Klantenvertellen
 *
 * Copyright 2019 by Oene Tjeerd de Bruin <modx@oetzie.nl>
 */

require_once dirname(__DIR__) . '/klantenvertellenreview.class.php';

class KlantenVertellenReview_mysql extends KlantenvertellenReview
{
}
