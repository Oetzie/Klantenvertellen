<?php

/**
 * Klantenvertellen
 *
 * Copyright 2019 by Oene Tjeerd de Bruin <modx@oetzie.nl>
 */

$xpdo_meta_map = [
    'xPDOSimpleObject' => [
        'KlantenVertellenReview'
    ]
];
